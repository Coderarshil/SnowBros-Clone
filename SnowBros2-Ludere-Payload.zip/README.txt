Snow Bros. 2 - Ludere payload

This payload is prepared for the Ludere Android ROM packager.
It uses the FBNeo libretro core and packages the supplied Snow Bros. 2 ROM.

Upload the contents of this folder as the payload for Ludere's Autogen workflow.
